const help = (prefix) => { 
	return `            	
┏━━━━°❀ ❬ *ABOUT* ❭ ❀°━━━━┓
┃╔═══════════════════╗
┏❉ *${prefix}owner*
┣❉ *${prefix}donasi*
┗❉ *${prefix}info*
┃╚═══════════════════╝
┣━━━━°❀ ❬ *MAKER* ❭ ❀°━━━━⊱
┃╔═══════════════════╗
┃╠➥ *${prefix}sticker* [FOTO,VIDEO,GIF]
┃╠➥ *${prefix}sticker nobg*
┃╠➥ *${prefix}tsticker*
┃╠➥ *${prefix}nulis*
┃╠➥ *${prefix}logowolf*
┃╚═══════════════════╝
┣━━━━°❀ ❬ *MEDIA* ❭ ❀°━━━━━⊱
┃╔═══════════════════╗
┃╠➥ *${prefix}tts*
┃╠➥ *${prefix}tiktok*
┃╠➥ *${prefix}meme*
┃╠➥ *${prefix}memeindo*
┃╠➥ *${prefix}nsfwloli* 
┃╠➥ *${prefix}ocr*
┃╠➥ *${prefix}neko*
┃╠➥ *${prefix}randomanime*
┃╠➥ *${prefix}loli*
┃╠➥ *${prefix}waifu*
┃╚═══════════════════╝
┣━━━°❀ ❬ *DOWNLOAD ❭ ❀°━━⊱
┃╔═══════════════════╗
┃╠➥ *${prefix}ytmp3*
┃╠➥ *${prefix}ytmp4*
┃╚═══════════════════╝
┣━━━━°❀ ❬ *GROUP* ❭ ❀°━━━━⊱
┃╔═══════════════════╗
┃╠➥ *${prefix}add* [62xxx]
┃╠➥ *${prefix}kick* [tag]
┃╠➥ *${prefix}setpp*
┃╠➥ *${prefix}tagme*
┃╠➥ *${prefix}demote* [tag]
┃╠➥ *${prefix}promote* [tag]
┃╠➥ *${prefix}grup* [buka/tutup]
┃╠➥ *${prefix}welcome* [1/0]
┃╠➥ *${prefix}nsfw* [1/0]
┃╠➥ *${prefix}simih* [1/0]
┃╚═══════════════════╝
┣━━━━°❀ ❬ *OWNER* ❭ ❀°━━━━⊱
┃╔═══════════════════╗
┃╠➥ *${prefix}bc* 
┃╠➥ *${prefix}clearall*
┃╠➥ *${prefix}setprefix*
┃╠➥ *${prefix}leave*
┃╠➥ *${prefix}clone* [tag]
┃╚═══════════════════╝
┣━━━━━°❀ ❬ *SPAM* ❭ ❀°━━━━━⊱
┃╔═══════════════════╗
┃╠➥ *${prefix}spamsms*
┃╠➥ *${prefix}spamcall*
┃╠➥ *${prefix}spamgmail*
┃╚═══════════════════╝
┣━━━━°❀ ❬ *OTHER* ❭ ❀°━━━━⊱
┃╔═══════════════════╗
┃╠➥ *${prefix}ytsearch*
┃╠➥ *${prefix}listadmin*
┃╠➥ *${prefix}blocklist*
┃╠➥ *${prefix}wait*
┃╠➥ *${prefix}nama*
┃╠➥ *${prefix}map*
┃╠➥ *${prefix}qrcode*
┃╠➥ *${prefix}tiktokstalk*
┃╠➥ *${prefix}shortlink*
┃╠➥ *${prefix}url2img*
┃╠➥ *${prefix}alay*
┃╠➥ *${prefix}quotes*
┃╠➥ *${prefix}bucin*
┃╠➥ *${prefix}wiki*
┃╠➥ *${prefix}wikien*
┃╚═══════════════════╝
┣━━━━°❀ ❬ *SOUND* ❭ ❀°━━━━⊱
┃╔═══════════════════╗
┃╠➥ *${prefix}tapi*
┃╚═══════════════════╝
┣━━━━━━━━━━━━━━━━━━━━━⊱
┣━━━━━━━━━━━━━━━━━━━━━┓
┃                   NewalBotツ
┣━━━━━━━━━━━━━━━━━━━━━⊱
┣━━━━°❀ ❬ *THX FOR* ❭ ❀°━━━⊱
┃ ╔═══════════════════╗
┃ ╠➥ ARIS187 ID
┃ ╠➥ MhankBarBar
┃ ╚═══════════════════╝
┗━━━━━━━━━━━━━━━━━━━━━┛`
}

exports.help = help

 